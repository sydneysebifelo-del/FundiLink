import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LogOut, Briefcase, User, Image } from "lucide-react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { JobCard } from "@/components/job-card";
import { BottomNav } from "@/components/bottom-nav";
import { type Job } from "@shared/schema";
import { useEffect, useState } from "react";

export default function ProviderDashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (!storedUser) {
      setLocation("/");
      return;
    }
    setUser(JSON.parse(storedUser));
  }, [setLocation]);

  const { data: jobs = [], isLoading } = useQuery<Job[]>({
    queryKey: ["/api/jobs"],
  });

  const acceptJobMutation = useMutation({
    mutationFn: async (jobId: string) => {
      const response = await apiRequest("POST", `/api/jobs/${jobId}/accept`, {});
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Job accepted!",
        description: "You have successfully accepted this job",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to accept job",
        variant: "destructive",
      });
    },
  });

  const handleLogout = () => {
    localStorage.removeItem("user");
    toast({
      title: "Logged out",
      description: "You have been logged out successfully",
    });
    setLocation("/");
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-500 to-blue-600 flex flex-col items-center text-white p-4 pb-24">
      <div className="w-full max-w-sm mt-6">
        <Card className="bg-white text-foreground shadow-xl">
          <CardContent className="flex flex-col gap-4 p-6 max-h-[80vh] overflow-y-auto">
            <h2 className="text-xl font-semibold text-center text-chart-2" data-testid="text-welcome">
              Welcome, {user.name}!
            </h2>
            {user.skill && (
              <p className="text-sm text-center text-muted-foreground -mt-2" data-testid="text-skill">
                {user.skill}
              </p>
            )}

            <div className="flex flex-col gap-3">
              <h3 className="text-base font-semibold text-foreground flex items-center gap-2">
                <Briefcase size={18} />
                Available Jobs
              </h3>
              {isLoading && (
                <p className="text-muted-foreground text-sm text-center py-4">Loading jobs...</p>
              )}
              {!isLoading && jobs.length === 0 && (
                <p className="text-muted-foreground text-sm text-center py-4" data-testid="text-no-jobs">
                  No jobs available. Check back soon!
                </p>
              )}
              <div className="space-y-3">
                {jobs.map((job) => (
                  <JobCard 
                    key={job.id} 
                    job={job} 
                    userRole="provider"
                    onAccept={acceptJobMutation.mutate}
                    isAccepting={acceptJobMutation.isPending}
                  />
                ))}
              </div>
            </div>

            <div className="flex gap-2 mt-4">
              <Button 
                onClick={() => setLocation(`/provider/${user.id}`)} 
                variant="outline"
                className="flex-1 flex items-center justify-center gap-2"
                data-testid="button-view-profile"
              >
                <User size={16} />
                My Profile
              </Button>
              <Button 
                onClick={() => setLocation(`/portfolio/${user.id}`)} 
                variant="outline"
                className="flex-1 flex items-center justify-center gap-2"
                data-testid="button-manage-portfolio"
              >
                <Image size={16} />
                Portfolio
              </Button>
            </div>

            <Button 
              onClick={handleLogout} 
              variant="secondary"
              className="mt-2 flex items-center justify-center gap-2"
              data-testid="button-logout"
            >
              <LogOut size={16} />
              Logout
            </Button>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </div>
  );
}
