import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowLeft, Plus, Trash2, Upload } from "lucide-react";
import { useLocation, useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useEffect, useState } from "react";
import { ObjectUploader } from "@/components/ObjectUploader";
import type { UploadResult } from "@uppy/core";

interface PortfolioImage {
  id: string;
  imageUrl: string;
  caption: string | null;
  timestamp: Date;
}

const portfolioSchema = z.object({
  imageUrl: z.string().min(1, "Please upload an image"),
  caption: z.string().optional(),
});

type PortfolioForm = z.infer<typeof portfolioSchema>;

export default function PortfolioManagement() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/portfolio/:providerId");
  const providerId = params?.providerId;
  const { toast } = useToast();
  const [user, setUser] = useState<any>(null);
  const [uploadedImageUrl, setUploadedImageUrl] = useState<string>("");
  const [isUploading, setIsUploading] = useState(false);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (!storedUser) {
      setLocation("/");
      return;
    }
    const parsedUser = JSON.parse(storedUser);
    if (parsedUser.id !== providerId || parsedUser.role !== "provider") {
      setLocation("/");
      return;
    }
    setUser(parsedUser);
  }, [setLocation, providerId]);

  const form = useForm<PortfolioForm>({
    resolver: zodResolver(portfolioSchema),
    defaultValues: {
      imageUrl: "",
      caption: "",
    },
  });

  const { data: portfolio = [], isLoading } = useQuery<PortfolioImage[]>({
    queryKey: ["/api/providers", providerId, "portfolio"],
    enabled: !!providerId,
  });

  const handleGetUploadParameters = async () => {
    const response = await fetch("/api/objects/upload", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-user": JSON.stringify(user),
      },
    });
    const data = await response.json();
    return {
      method: "PUT" as const,
      url: data.uploadURL,
    };
  };

  const handleUploadComplete = async (result: UploadResult<Record<string, unknown>, Record<string, unknown>>) => {
    if (result.successful && result.successful.length > 0) {
      const uploadURL = result.successful[0].uploadURL;
      if (uploadURL) {
        // Strip query parameters from the upload URL
        const cleanURL = uploadURL.split('?')[0];
        setUploadedImageUrl(cleanURL);
        form.setValue("imageUrl", cleanURL);
        
        toast({
          title: "Image uploaded!",
          description: "Image ready to add to portfolio",
        });
      }
    }
    setIsUploading(false);
  };

  const addImageMutation = useMutation({
    mutationFn: async (data: PortfolioForm) => {
      const response = await apiRequest("POST", `/api/providers/${providerId}/portfolio`, data);
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Image added!",
        description: "Your portfolio has been updated",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/providers", providerId, "portfolio"] });
      form.reset();
      setUploadedImageUrl("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add image",
        variant: "destructive",
      });
    },
  });

  const deleteImageMutation = useMutation({
    mutationFn: async (imageId: string) => {
      const response = await apiRequest("DELETE", `/api/portfolio/${imageId}`, {});
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Image deleted",
        description: "Image removed from your portfolio",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/providers", providerId, "portfolio"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete image",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: PortfolioForm) => {
    addImageMutation.mutate(data);
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-500 to-blue-600 flex flex-col items-center text-white p-4 pb-24">
      <div className="w-full max-w-2xl mt-6 space-y-4">
        <Card className="bg-white text-foreground shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Manage Portfolio</span>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setLocation("/provider")}
                data-testid="button-back"
              >
                <ArrowLeft size={20} />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="font-semibold text-lg mb-3">Add New Image</h3>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
                  <FormField
                    control={form.control}
                    name="imageUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Upload Image</FormLabel>
                        <FormControl>
                          <div className="space-y-2">
                            <ObjectUploader
                              maxNumberOfFiles={1}
                              maxFileSize={5242880}
                              onGetUploadParameters={handleGetUploadParameters}
                              onComplete={handleUploadComplete}
                              buttonVariant="outline"
                              buttonClassName="w-full"
                            >
                              <Upload className="mr-2 h-4 w-4" />
                              {uploadedImageUrl ? "Change Image" : "Browse & Upload Image"}
                            </ObjectUploader>
                            {uploadedImageUrl && (
                              <div className="relative aspect-square w-full max-w-xs mx-auto rounded-lg overflow-hidden border">
                                <img
                                  src={`/api/images/${uploadedImageUrl}`}
                                  alt="Preview"
                                  className="w-full h-full object-cover"
                                />
                              </div>
                            )}
                            <Input
                              type="hidden"
                              {...field}
                              data-testid="input-image-url"
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="caption"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Caption (Optional)</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Describe this project..."
                            {...field}
                            data-testid="input-caption"
                            className="resize-none"
                            rows={2}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full"
                    disabled={addImageMutation.isPending}
                    data-testid="button-add-image"
                  >
                    <Plus size={16} className="mr-2" />
                    {addImageMutation.isPending ? "Adding..." : "Add Image"}
                  </Button>
                </form>
              </Form>
            </div>

            <div className="border-t pt-6">
              <h3 className="font-semibold text-lg mb-3">
                Your Portfolio ({portfolio.length} {portfolio.length === 1 ? "image" : "images"})
              </h3>
              {isLoading && (
                <p className="text-center text-muted-foreground py-8">Loading...</p>
              )}
              {!isLoading && portfolio.length === 0 && (
                <p className="text-center text-muted-foreground py-8" data-testid="text-no-images">
                  No portfolio images yet. Add your first one above!
                </p>
              )}
              <div className="grid grid-cols-2 gap-4">
                {portfolio.map((image) => (
                  <div
                    key={image.id}
                    className="relative group"
                    data-testid={`portfolio-item-${image.id}`}
                  >
                    <div className="relative aspect-square rounded-lg overflow-hidden">
                      <img
                        src={`/api/images/${image.imageUrl}`}
                        alt={image.caption || "Portfolio image"}
                        className="w-full h-full object-cover"
                      />
                      {image.caption && (
                        <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white p-2 text-xs">
                          {image.caption}
                        </div>
                      )}
                    </div>
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => deleteImageMutation.mutate(image.id)}
                      disabled={deleteImageMutation.isPending}
                      data-testid={`button-delete-${image.id}`}
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
