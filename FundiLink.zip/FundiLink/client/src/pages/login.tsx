import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { LogIn, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const loginSchema = z.object({
  email: z.string().min(1, "Email is required"),
  password: z.string().min(1, "Password is required"),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function Login({ params }: { params: { role: string } }) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const role = params.role;

  const form = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const loginMutation = useMutation({
    mutationFn: async (data: LoginForm) => {
      const response = await apiRequest("POST", "/api/login", { ...data, role });
      return response;
    },
    onSuccess: (data) => {
      toast({
        title: "Welcome back!",
        description: `Logged in as ${data.user.name}`,
      });
      localStorage.setItem("user", JSON.stringify(data.user));
      setLocation(role === "client" ? "/client" : "/provider");
    },
    onError: (error: any) => {
      toast({
        title: "Login failed",
        description: error.message || "Invalid credentials or role mismatch",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: LoginForm) => {
    loginMutation.mutate(data);
  };

  const roleColor = role === "client" ? "text-primary" : "text-chart-2";

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-500 to-blue-600 flex flex-col items-center text-white p-4">
      <div className="w-full max-w-sm mt-10">
        <Card className="bg-white text-foreground shadow-xl">
          <CardContent className="flex flex-col gap-4 p-6">
            <h2 className={`text-xl font-semibold text-center ${roleColor} flex items-center justify-center gap-2`}>
              <LogIn size={22} />
              {role === "provider" ? "Provider Login" : "Client Login"}
            </h2>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email or Phone Number</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter your email or phone" 
                          {...field}
                          data-testid="input-email"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input 
                          type="password"
                          placeholder="Enter your password" 
                          {...field}
                          data-testid="input-password"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full mt-2"
                  disabled={loginMutation.isPending}
                  data-testid="button-login-submit"
                >
                  {loginMutation.isPending ? "Logging in..." : "Login"}
                </Button>
              </form>
            </Form>

            <p className="text-sm text-center text-muted-foreground mt-2">
              Don't have an account?{" "}
              <span 
                onClick={() => setLocation(`/signup/${role}`)} 
                className="text-primary hover:underline cursor-pointer"
                data-testid="link-signup"
              >
                Sign Up
              </span>
            </p>
            
            <Button 
              onClick={() => setLocation("/")} 
              variant="outline" 
              className="mt-2"
              data-testid="button-back"
            >
              <ArrowLeft size={16} className="mr-2" />
              Back
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
