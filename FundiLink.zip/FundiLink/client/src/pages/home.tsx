import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Handshake } from "lucide-react";
import { useLocation } from "wouter";

export default function Home() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-500 to-blue-600 flex flex-col items-center text-white p-4">
      <motion.div 
        initial={{ opacity: 0, y: -20 }} 
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex items-center gap-2 mt-8"
      >
        <Handshake size={36} className="text-white" />
        <h1 className="text-3xl font-bold tracking-tight">FundiLink</h1>
      </motion.div>
      <p className="text-sm mt-2 italic opacity-90">Connecting You to Skilled Hands</p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="w-full max-w-sm mt-16"
      >
        <Card className="bg-white text-foreground shadow-xl">
          <CardContent className="flex flex-col gap-4 p-6">
            <h2 className="text-xl font-semibold text-center">Welcome to FundiLink</h2>
            <p className="text-center text-sm text-muted-foreground">
              Find trusted professionals or register as a service provider.
            </p>
            <Button 
              onClick={() => setLocation("/login/client")} 
              className="w-full text-base"
              size="lg"
              data-testid="button-need-service"
            >
              I Need a Service
            </Button>
            <Button 
              onClick={() => setLocation("/login/provider")} 
              variant="secondary"
              className="w-full text-base bg-chart-2 text-white hover:bg-chart-2/90"
              size="lg"
              data-testid="button-am-provider"
            >
              I Am a Provider
            </Button>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
