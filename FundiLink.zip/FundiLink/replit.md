# FundiLink - Service Marketplace Platform

## Overview
FundiLink is a mobile-first service marketplace web application connecting clients with skilled service providers. Its purpose is to facilitate job postings, provider discovery, and communication within a vibrant, user-friendly platform. The project aims to create a seamless experience for both clients seeking services and providers offering them, featuring a distinctive orange-blue gradient design.

## User Preferences
I prefer simple language and detailed explanations. I want iterative development, with clear communication before major changes. Do not make changes to the folder `Z` or the file `Y`.

## System Architecture
The platform is built with a modern web stack, emphasizing a mobile-first approach and a clean, responsive UI.

**UI/UX Decisions:**
- **Design Language**: Orange-blue gradient theme with a professional aesthetic.
- **Responsiveness**: Mobile-first design principles, ensuring adaptability across various devices.
- **Animations**: Smooth transitions and interactive elements powered by Framer Motion.
- **Navigation**: Intuitive bottom navigation for core functionalities (Home, Messages, Profile).
- **Component Library**: Utilizes Shadcn UI for consistent and accessible components.
- **Key UI Features**: Card-based layouts, star rating components, and a dedicated chat interface.

**Technical Implementations:**
- **Frontend**: React with TypeScript, Tailwind CSS, Shadcn UI, Framer Motion, and Wouter for routing.
- **Backend**: Express.js with TypeScript, providing RESTful API endpoints.
- **Database**: PostgreSQL (Neon-backed) managed with Drizzle ORM for type-safe operations.
- **State Management**: TanStack React Query handles server-side state, with localStorage for authentication.
- **Authentication**: User registration and login for `client` and `provider` roles. User authentication details are stored in `localStorage` and sent via `x-user` header.
- **File Upload System**: Integration with Replit Object Storage (S3-compatible) for profile pictures and portfolio images, utilizing presigned URLs for secure direct uploads.
- **Messaging System**: Real-time messaging between clients and providers, supporting both job-based and direct conversations.
- **User Profiles**: Detailed provider profiles include skills, ratings, reviews, contact information, and a photo portfolio.
- **Job Management**: Clients can post jobs, and providers can view and accept them, with real-time status updates.
- **Review System**: Clients can submit 1-5 star ratings and text reviews for providers post-job completion.
- **Provider Discovery**: Clients can browse all registered service providers, view their profiles, and initiate direct messages.

**Feature Specifications:**
- **User Roles**: Differentiated functionalities for Clients (post jobs, browse providers, review) and Providers (view jobs, accept jobs, manage profile/portfolio).
- **Portfolio Management**: Providers can upload, caption, and manage images for their professional portfolio.
- **Profile Editing**: Users can update their profile details (phone, bio, skill, profile picture) through a dedicated interface.

**System Design Choices:**
- **Monorepo Structure**: `client` and `server` directories within a single repository for streamlined development.
- **API Design**: RESTful architecture with JSON request/response, consistent error handling, and Zod for validation.
- **Database Schema**: Clearly defined models for `User`, `Job`, `Review`, `Message`, and `PortfolioImage` with UUIDs as primary keys.

## External Dependencies
- **Database**: Neon (PostgreSQL)
- **ORM**: Drizzle ORM
- **Object Storage**: Replit Object Storage (S3-compatible for image uploads)
- **UI Components**: Shadcn UI
- **Animation Library**: Framer Motion
- **State Management**: TanStack React Query
- **File Uploader**: Uppy Dashboard (for file selection interface)