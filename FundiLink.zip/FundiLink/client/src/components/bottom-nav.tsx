import { Button } from "@/components/ui/button";
import { Home, User, MessageCircle } from "lucide-react";
import { useLocation } from "wouter";

export function BottomNav() {
  const [, setLocation] = useLocation();

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/10 backdrop-blur-md flex justify-around py-3 border-t border-white/20 z-50">
      <Button 
        variant="ghost" 
        onClick={() => setLocation("/")} 
        className="flex flex-col items-center text-white hover:bg-white/20 gap-1 h-auto py-2"
        data-testid="button-nav-home"
      >
        <Home size={20} />
        <span className="text-xs">Home</span>
      </Button>
      <Button 
        variant="ghost" 
        onClick={() => setLocation("/messages")} 
        className="flex flex-col items-center text-white hover:bg-white/20 gap-1 h-auto py-2"
        data-testid="button-nav-messages"
      >
        <MessageCircle size={20} />
        <span className="text-xs">Messages</span>
      </Button>
      <Button 
        variant="ghost" 
        onClick={() => setLocation("/login/provider")} 
        className="flex flex-col items-center text-white hover:bg-white/20 gap-1 h-auto py-2"
        data-testid="button-nav-login"
      >
        <User size={20} />
        <span className="text-xs">Profile</span>
      </Button>
    </div>
  );
}
