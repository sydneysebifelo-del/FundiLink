# FundiLink Design Guidelines

## Design Approach

**Reference-Based Design** inspired by successful service marketplace platforms (Airbnb, TaskRabbit, Upwork) with a focus on trust-building, accessibility, and mobile-first experience. The existing orange-blue brand identity will be refined and expanded.

## Core Design Elements

### A. Color Palette

**Primary Colors:**
- **Orange (Client/Primary):** 25 95% 53% - vibrant, action-oriented for client-facing elements
- **Blue (Provider/Secondary):** 221 83% 53% - professional, trustworthy for provider-facing elements
- **Background Gradient:** Linear gradient from orange-500 to blue-600 for app shell

**Supporting Colors:**
- **Success Green:** 142 71% 45% - for accepted jobs, confirmations
- **Neutral Gray:** 215 16% 47% - for secondary text, borders
- **Surface White:** 0 0% 100% - for cards, input backgrounds
- **Text Primary:** 222 47% 11% - for main content on light backgrounds
- **Text Muted:** 215 16% 47% - for secondary information

**Dark Mode (Future Consideration):**
- Maintain orange/blue identity with desaturated variants
- Surface: 222 47% 11%
- Text: 210 40% 98%

### B. Typography

**Font Stack:**
- Primary: 'Inter' via Google Fonts for clean, modern readability
- Fallback: system-ui, -apple-system, sans-serif

**Type Scale:**
- Hero/Display: text-3xl (30px), font-bold, tracking-tight
- Section Headers: text-xl (20px), font-semibold
- Body Large: text-base (16px), font-normal
- Body Default: text-sm (14px), font-normal
- Caption/Meta: text-xs (12px), font-normal
- Labels: text-sm (14px), font-medium

### C. Layout System

**Spacing Primitives:**
- Use Tailwind units: 2, 3, 4, 6, 8, 10, 12 for consistent rhythm
- Component padding: p-6 for cards, p-4 for dense content
- Section gaps: gap-4 for related items, gap-6 for distinct sections
- Vertical spacing: mt-4, mt-6, mt-10 for content flow

**Container Strategy:**
- Max-width: max-w-sm (384px) for mobile-first card layouts
- Padding: px-4 for screen edges
- Full-screen gradient background with centered content cards

### D. Component Library

**Navigation:**
- Fixed bottom navigation bar with blur backdrop (bg-white/10 backdrop-blur-md)
- Icon + label combination for clarity
- Ghost variant buttons for navigation items
- Active state: subtle brightness increase

**Cards:**
- White surface with rounded-2xl corners
- Drop shadow: shadow-xl for elevated feeling
- Padding: p-6 for breathing room
- Border-left accent (4px) for job cards with status-based colors

**Buttons:**
- Primary (Orange): bg-orange-500 hover:bg-orange-600, full rounded-xl corners
- Secondary (Blue): bg-blue-600 hover:bg-blue-700
- Outline: variant="outline" with border-gray-300
- Ghost: for navigation, transparent background
- Sizes: Default py-2, Small text-xs mt-2 for inline actions
- All buttons include subtle hover transitions

**Forms:**
- Input fields: Clean white backgrounds with subtle borders
- Placeholder text: text-gray-500
- Focus states: Orange ring for client context, blue for provider
- Label placement: Above inputs when needed, placeholders for simple forms
- Grouped form sections with border-b separators

**Job Cards:**
- Status-based border-left colors: orange-500 (pending), green-500 (accepted)
- Background: bg-gray-100 for subtle contrast
- Emoji icons: 📍 for location, 🕒 for timestamp
- Hierarchical text: Bold title, normal description, muted metadata
- Action buttons inline at card bottom

**Status Indicators:**
- Color-coded text: orange-500 (pending), green-600 (accepted)
- Font-weight: font-semibold for prominence
- Size: text-xs for compact display

**Modals/Overlays:**
- If needed: backdrop-blur-lg with semi-transparent dark overlay
- Centered cards following same rounded-2xl style
- Close button: top-right with X icon

### E. Animations

**Minimal, Purposeful Motion:**
- Page transitions: Fade-in with subtle y-translation (framer-motion initial/animate)
- Button hovers: Color darkening (built into Tailwind hover states)
- Job acceptance: Instant visual feedback, no elaborate animations
- Avoid: Carousels, parallax, scroll-triggered effects

**Micro-interactions:**
- Input focus: Smooth ring appearance
- Button press: Slight scale reduction (scale-95 on active state)
- Card hover: None - keep mobile-friendly

## Images

**Header Logo Area:**
- Icon-based branding (Handshake icon) with wordmark
- No photographic hero image - gradient background provides visual interest
- Keep interface clean and form-focused

**Job Listings:**
- No images in current scope - prioritize information density
- Future: Small avatar/thumbnail for service providers (circular, 40x40px)

**Empty States:**
- Simple text-based messaging with supporting icons
- "No jobs yet" message with friendly copy

## Accessibility

- Maintain WCAG AA contrast ratios minimum
- All interactive elements minimum 44x44px touch targets
- Semantic HTML with proper heading hierarchy
- Focus visible states on all interactive elements
- Screen reader friendly labels for icon-only buttons
- Form validation messages clearly visible
- Status colors supplemented with text/icons (not color alone)

## Mobile-First Considerations

- Single column layouts throughout
- Fixed bottom navigation for thumb-friendly access
- Generous touch targets (py-2 minimum on buttons)
- Vertical scrolling for job lists with max-h-[70vh]
- No horizontal scrolling
- Full-width buttons for primary actions

---

**Design Principles:**
1. **Trust First:** Clean, professional aesthetics build confidence in the platform
2. **Role Clarity:** Color-coding (orange/blue) helps users understand context immediately  
3. **Information Hierarchy:** Bold titles, clear metadata, status-first display
4. **Friction Reduction:** Minimal steps from login to job posting/acceptance
5. **Mobile Native:** Designed for on-the-go service discovery and management