import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Star, MapPin } from "lucide-react";
import { useLocation } from "wouter";

interface ProviderCardProps {
  provider: {
    id: string;
    name: string;
    skill: string | null;
    profilePicture: string | null;
    phone: string | null;
    averageRating: number;
  };
}

export function ProviderCard({ provider }: ProviderCardProps) {
  const [, setLocation] = useLocation();

  const handleClick = () => {
    setLocation(`/provider/${provider.id}`);
  };

  return (
    <Card 
      className="hover-elevate active-elevate-2 cursor-pointer"
      onClick={handleClick}
      data-testid={`card-provider-${provider.id}`}
    >
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <Avatar className="h-12 w-12" data-testid="img-provider-avatar">
            <AvatarImage 
              src={provider.profilePicture ? `/api/images/${provider.profilePicture}` : undefined}
              alt={provider.name}
            />
            <AvatarFallback className="bg-primary text-primary-foreground">
              {provider.name.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1 min-w-0">
            <h4 className="font-semibold text-foreground truncate" data-testid="text-provider-name">
              {provider.name}
            </h4>
            <p className="text-sm text-muted-foreground truncate" data-testid="text-provider-skill">
              {provider.skill || "Service Provider"}
            </p>
            {provider.phone && (
              <p className="text-xs text-muted-foreground truncate" data-testid="text-provider-phone">
                {provider.phone}
              </p>
            )}
          </div>

          <div className="flex flex-col items-end gap-1">
            <div className="flex items-center gap-1" data-testid="text-provider-rating">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span className="text-sm font-semibold text-foreground">
                {provider.averageRating > 0 ? provider.averageRating.toFixed(1) : "New"}
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
