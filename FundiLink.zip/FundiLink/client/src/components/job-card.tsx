import { Button } from "@/components/ui/button";
import { MapPin, Clock, Star, User, MessageCircle } from "lucide-react";
import { type Job } from "@shared/schema";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useState } from "react";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";

interface JobCardProps {
  job: Job;
  userRole: string;
  currentUserId?: string;
  onAccept?: (jobId: string) => void;
  isAccepting?: boolean;
}

export function JobCard({ job, userRole, currentUserId, onAccept, isAccepting }: JobCardProps) {
  const isAccepted = job.status.startsWith("Accepted");
  const statusColor = isAccepted ? "border-l-chart-3" : "border-l-primary";
  const statusTextColor = isAccepted ? "text-chart-3" : "text-primary";
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [isReviewDialogOpen, setIsReviewDialogOpen] = useState(false);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const canReview = userRole === "client" && isAccepted && job.postedById === currentUserId && job.acceptedById;

  const handleSubmitReview = async () => {
    if (!job.acceptedById) return;

    setIsSubmitting(true);
    try {
      await apiRequest("POST", "/api/reviews", {
        providerId: job.acceptedById,
        jobId: job.id,
        rating,
        comment,
      });

      toast({
        title: "Review submitted!",
        description: "Thank you for your feedback",
      });
      setIsReviewDialogOpen(false);
      setComment("");
      setRating(5);
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to submit review",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleViewProvider = () => {
    if (job.acceptedById) {
      setLocation(`/provider/${job.acceptedById}`);
    }
  };

  return (
    <div 
      className={`border-l-4 ${statusColor} bg-muted p-4 rounded-md shadow-sm space-y-2`}
      data-testid={`card-job-${job.id}`}
    >
      <h4 className="font-semibold text-foreground text-base" data-testid="text-job-service">
        {job.service}
      </h4>
      <p className="text-muted-foreground text-sm" data-testid="text-job-description">
        {job.description}
      </p>
      <div className="flex items-center gap-1 text-muted-foreground text-xs">
        <MapPin size={14} />
        <span data-testid="text-job-location">{job.location}</span>
      </div>
      <div className="flex items-center gap-1 text-muted-foreground text-xs">
        <Clock size={14} />
        <span data-testid="text-job-timestamp">
          Posted {job.timestamp ? format(new Date(job.timestamp), "MMM d, yyyy 'at' h:mm a") : "recently"}
        </span>
      </div>
      <p className={`text-xs font-semibold ${statusTextColor}`} data-testid="text-job-status">
        {job.status}
      </p>

      {userRole === "provider" && !isAccepted && onAccept && (
        <Button 
          className="bg-chart-2 hover:bg-chart-2/90 text-white text-xs mt-2" 
          size="sm"
          onClick={() => onAccept(job.id)}
          disabled={isAccepting}
          data-testid={`button-accept-${job.id}`}
        >
          {isAccepting ? "Accepting..." : "Accept Job"}
        </Button>
      )}

      {isAccepted && job.acceptedBy && (
        <div className="flex flex-wrap gap-2 mt-2">
          <Button 
            variant="outline" 
            size="sm"
            className="text-xs flex items-center gap-1"
            onClick={handleViewProvider}
            data-testid={`button-view-provider-${job.id}`}
          >
            <User size={14} />
            View {job.acceptedBy}
          </Button>

          <Button 
            variant="outline" 
            size="sm"
            className="text-xs flex items-center gap-1"
            onClick={() => setLocation(`/messages/${job.id}`)}
            data-testid={`button-message-${job.id}`}
          >
            <MessageCircle size={14} />
            Message
          </Button>
          
          {canReview && (
            <Dialog open={isReviewDialogOpen} onOpenChange={setIsReviewDialogOpen}>
              <DialogTrigger asChild>
                <Button 
                  size="sm"
                  className="text-xs flex items-center gap-1"
                  data-testid={`button-review-${job.id}`}
                >
                  <Star size={14} />
                  Leave Review
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Review {job.acceptedBy}</DialogTitle>
                  <DialogDescription>
                    Share your experience working with this provider
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>Rating</Label>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setRating(star)}
                          className="focus:outline-none"
                          data-testid={`button-rating-${star}`}
                        >
                          <Star
                            size={32}
                            className={`${
                              star <= rating
                                ? "fill-yellow-400 text-yellow-400"
                                : "text-gray-300"
                            } hover:scale-110 transition-transform`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="comment">Your Review</Label>
                    <Textarea
                      id="comment"
                      placeholder="Share your experience..."
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      data-testid="textarea-review-comment"
                    />
                  </div>
                </div>

                <DialogFooter>
                  <Button
                    onClick={handleSubmitReview}
                    disabled={isSubmitting || !comment}
                    data-testid="button-submit-review"
                  >
                    {isSubmitting ? "Submitting..." : "Submit Review"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>
      )}
    </div>
  );
}
