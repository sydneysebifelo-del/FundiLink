import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { UserPlus, ArrowLeft, Upload } from "lucide-react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ObjectUploader } from "@/components/ObjectUploader";
import type { UploadResult } from "@uppy/core";
import { useState } from "react";

const signupSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().min(1, "Email is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  skill: z.string().optional(),
  phone: z.string().optional(),
  bio: z.string().optional(),
  profilePicture: z.string().optional(),
});

type SignupForm = z.infer<typeof signupSchema>;

export default function Signup({ params }: { params: { role: string } }) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const role = params.role;
  const [uploadedImageUrl, setUploadedImageUrl] = useState<string>("");
  const [isUploading, setIsUploading] = useState(false);

  const form = useForm<SignupForm>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      name: "",
      email: "",
      password: "",
      skill: "",
      phone: "",
      bio: "",
      profilePicture: "",
    },
  });

  const signupMutation = useMutation({
    mutationFn: async (data: SignupForm) => {
      const response = await apiRequest("POST", "/api/signup", { ...data, role });
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Account created!",
        description: "Please login to continue",
      });
      setLocation(`/login/${role}`);
    },
    onError: (error: any) => {
      toast({
        title: "Signup failed",
        description: error.message || "User already exists or invalid data",
        variant: "destructive",
      });
    },
  });

  const handleGetUploadParameters = async () => {
    const user = { id: "temp-id", name: form.getValues("name") };
    const response = await fetch("/api/objects/upload", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-user": JSON.stringify(user),
      },
    });
    const data = await response.json();
    return {
      method: "PUT" as const,
      url: data.uploadURL,
    };
  };

  const handleUploadComplete = async (result: UploadResult<Record<string, unknown>, Record<string, unknown>>) => {
    if (result.successful && result.successful.length > 0) {
      const uploadURL = result.successful[0].uploadURL;
      if (uploadURL) {
        // Strip query parameters from the upload URL
        const cleanURL = uploadURL.split('?')[0];
        setUploadedImageUrl(cleanURL);
        form.setValue("profilePicture", cleanURL);
        
        toast({
          title: "Image uploaded!",
          description: "Your profile picture has been uploaded successfully",
        });
      }
    }
    setIsUploading(false);
  };

  const onSubmit = (data: SignupForm) => {
    signupMutation.mutate(data);
  };

  const roleColor = role === "client" ? "text-primary" : "text-chart-2";

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-500 to-blue-600 flex flex-col items-center text-white p-4">
      <div className="w-full max-w-sm mt-10">
        <Card className="bg-white text-foreground shadow-xl">
          <CardContent className="flex flex-col gap-4 p-6">
            <h2 className={`text-xl font-semibold text-center ${roleColor} flex items-center justify-center gap-2`}>
              <UserPlus size={22} />
              {role === "provider" ? "Provider Sign Up" : "Client Sign Up"}
            </h2>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter your full name" 
                          {...field}
                          data-testid="input-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email or Phone Number</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter your email or phone" 
                          {...field}
                          data-testid="input-email"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input 
                          type="password"
                          placeholder="Create a password" 
                          {...field}
                          data-testid="input-password"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {role === "provider" && (
                  <>
                    <FormField
                      control={form.control}
                      name="skill"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Skill or Profession</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="e.g. Electrician, Plumber, Carpenter" 
                              {...field}
                              data-testid="input-skill"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="e.g. +254 712 345 678" 
                              {...field}
                              data-testid="input-phone"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="bio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Brief Bio</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell clients about your experience and services..." 
                              {...field}
                              data-testid="input-bio"
                              className="resize-none"
                              rows={3}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="space-y-2">
                      <FormLabel>Profile Picture (Optional)</FormLabel>
                      <ObjectUploader
                        maxNumberOfFiles={1}
                        maxFileSize={5242880}
                        onGetUploadParameters={handleGetUploadParameters}
                        onComplete={handleUploadComplete}
                        buttonVariant="outline"
                        buttonClassName="w-full"
                      >
                        <div className="flex items-center gap-2">
                          <Upload size={16} />
                          <span>{uploadedImageUrl ? "Change Picture" : "Upload Picture"}</span>
                        </div>
                      </ObjectUploader>
                      {uploadedImageUrl && (
                        <p className="text-xs text-green-600" data-testid="text-upload-success">
                          ✓ Profile picture uploaded
                        </p>
                      )}
                    </div>
                  </>
                )}

                <Button 
                  type="submit" 
                  className="w-full mt-2"
                  disabled={signupMutation.isPending}
                  data-testid="button-signup-submit"
                >
                  {signupMutation.isPending ? "Creating account..." : "Sign Up"}
                </Button>
              </form>
            </Form>

            <p className="text-sm text-center text-muted-foreground mt-2">
              Already have an account?{" "}
              <span 
                onClick={() => setLocation(`/login/${role}`)} 
                className="text-primary hover:underline cursor-pointer"
                data-testid="link-login"
              >
                Login
              </span>
            </p>
            
            <Button 
              onClick={() => setLocation("/")} 
              variant="outline" 
              className="mt-2"
              data-testid="button-back"
            >
              <ArrowLeft size={16} className="mr-2" />
              Back
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
