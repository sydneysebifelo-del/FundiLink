import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, Link, useLocation } from "wouter";
import { Star, Phone, Briefcase, Mail, Edit, MessageCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Review {
  id: string;
  rating: number;
  comment: string;
  timestamp: Date;
  clientId: string;
}

interface PortfolioImage {
  id: string;
  imageUrl: string;
  caption: string | null;
  timestamp: Date;
}

interface ProviderData {
  id: string;
  name: string;
  email: string;
  skill: string | null;
  phone: string | null;
  bio: string | null;
  profilePicture: string | null;
  averageRating: number;
}

export default function ProviderProfile() {
  const [, params] = useRoute("/provider/:id");
  const providerId = params?.id;
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const userStr = localStorage.getItem("user");
  const currentUser = userStr ? JSON.parse(userStr) : null;
  const isOwnProfile = currentUser && currentUser.id === providerId;
  const isClient = currentUser && currentUser.role === "client";

  const handleMessageProvider = () => {
    if (!currentUser) {
      toast({
        title: "Not logged in",
        description: "Please log in to message this provider",
        variant: "destructive",
      });
      return;
    }
    // Navigate to direct message conversation
    setLocation(`/messages/direct-${providerId}`);
  };

  const { data: provider, isLoading: isLoadingProvider } = useQuery<ProviderData>({
    queryKey: ["/api/providers", providerId],
    enabled: !!providerId,
  });

  const { data: reviewsData, isLoading: isLoadingReviews } = useQuery<{ reviews: Review[]; averageRating: number }>({
    queryKey: ["/api/providers", providerId, "reviews"],
    enabled: !!providerId,
  });

  const { data: portfolio, isLoading: isLoadingPortfolio } = useQuery<PortfolioImage[]>({
    queryKey: ["/api/providers", providerId, "portfolio"],
    enabled: !!providerId,
  });

  if (isLoadingProvider || isLoadingReviews || isLoadingPortfolio) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-500 to-blue-600 p-4">
        <div className="max-w-4xl mx-auto pt-8">
          <Card>
            <CardContent className="p-8">
              <p className="text-center text-muted-foreground">Loading...</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!provider) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-500 to-blue-600 p-4">
        <div className="max-w-4xl mx-auto pt-8">
          <Card>
            <CardContent className="p-8">
              <p className="text-center text-muted-foreground">Provider not found</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const reviews = reviewsData?.reviews || [];
  const averageRating = reviewsData?.averageRating || 0;
  const portfolioImages = portfolio || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-500 to-blue-600 p-4">
      <div className="max-w-4xl mx-auto pt-8 pb-24 space-y-4">
        <div className="flex justify-end gap-2">
          {isOwnProfile && (
            <Link href="/edit-profile">
              <Button variant="outline" className="bg-white" data-testid="button-edit-profile">
                <Edit className="mr-2 h-4 w-4" />
                Edit Profile
              </Button>
            </Link>
          )}
          {isClient && !isOwnProfile && (
            <Button onClick={handleMessageProvider} className="bg-white text-foreground hover:bg-white/90" data-testid="button-message-provider">
              <MessageCircle className="mr-2 h-4 w-4" />
              Message Provider
            </Button>
          )}
        </div>
        
        <Card data-testid="card-provider-profile">
          <CardHeader>
            <div className="flex flex-col md:flex-row items-start gap-6">
              <Avatar className="h-32 w-32">
                <AvatarImage 
                  src={provider.profilePicture ? `/api/images/${provider.profilePicture}` : undefined}
                  alt={provider.name}
                />
                <AvatarFallback className="text-4xl bg-blue-500 text-white">
                  {provider.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 w-full">
                <CardTitle className="text-3xl mb-3" data-testid="text-provider-name">
                  {provider.name}
                </CardTitle>
                
                {provider.skill && (
                  <div className="flex items-center gap-2 mb-2">
                    <Briefcase className="h-5 w-5 text-chart-2" />
                    <span className="text-lg font-medium text-chart-2" data-testid="text-provider-skill">
                      {provider.skill}
                    </span>
                  </div>
                )}
                
                <div className="flex items-center gap-2 mb-4">
                  <Star className="h-6 w-6 fill-yellow-400 text-yellow-400" />
                  <span className="text-xl font-semibold" data-testid="text-average-rating">
                    {averageRating > 0 ? averageRating.toFixed(1) : "No ratings yet"}
                  </span>
                  {reviews.length > 0 && (
                    <span className="text-sm text-muted-foreground">
                      ({reviews.length} {reviews.length === 1 ? "review" : "reviews"})
                    </span>
                  )}
                </div>

                <div className="space-y-2">
                  {provider.phone && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="h-4 w-4" />
                      <span data-testid="text-provider-phone">{provider.phone}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Mail className="h-4 w-4" />
                    <span data-testid="text-provider-email">{provider.email}</span>
                  </div>
                </div>
              </div>
            </div>
          </CardHeader>
          
          {provider.bio && (
            <CardContent className="pt-0">
              <div className="border-t pt-4">
                <h3 className="font-semibold text-lg mb-2">About</h3>
                <p className="text-muted-foreground leading-relaxed" data-testid="text-provider-bio">
                  {provider.bio}
                </p>
              </div>
            </CardContent>
          )}
        </Card>

        {portfolioImages.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Portfolio</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {portfolioImages.map((image) => (
                  <div
                    key={image.id}
                    className="relative aspect-square rounded-lg overflow-hidden group"
                    data-testid={`portfolio-image-${image.id}`}
                  >
                    <img
                      src={`/api/images/${image.imageUrl}`}
                      alt={image.caption || "Portfolio image"}
                      className="w-full h-full object-cover transition-transform group-hover:scale-105"
                    />
                    {image.caption && (
                      <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white p-2 text-sm">
                        {image.caption}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Reviews ({reviews.length})</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {reviews.length === 0 ? (
              <p className="text-center text-muted-foreground py-8" data-testid="text-no-reviews">
                No reviews yet
              </p>
            ) : (
              reviews.map((review) => (
                <div
                  key={review.id}
                  className="border-b last:border-b-0 pb-4 last:pb-0"
                  data-testid={`review-${review.id}`}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`h-4 w-4 ${
                            star <= review.rating
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {format(new Date(review.timestamp), "MMM d, yyyy")}
                    </span>
                  </div>
                  <p className="text-sm" data-testid={`text-review-comment-${review.id}`}>
                    {review.comment}
                  </p>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
