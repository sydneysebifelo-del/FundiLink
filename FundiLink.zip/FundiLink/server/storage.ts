import { users, jobs, reviews, messages, portfolioImages, type User, type InsertUser, type Job, type InsertJob, type Review, type InsertReview, type Message, type InsertMessage, type PortfolioImage, type InsertPortfolioImage } from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, avg, or, isNull } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  getAllProviders(): Promise<User[]>;
  
  getJob(id: string): Promise<Job | undefined>;
  getAllJobs(): Promise<Job[]>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: string, updates: Partial<Job>): Promise<Job | undefined>;
  
  getReview(id: string): Promise<Review | undefined>;
  getReviewsByProvider(providerId: string): Promise<Review[]>;
  getReviewByJobId(jobId: string): Promise<Review | undefined>;
  createReview(review: InsertReview): Promise<Review>;
  getProviderRating(providerId: string): Promise<number>;
  
  getMessage(id: string): Promise<Message | undefined>;
  getMessagesByJob(jobId: string): Promise<Message[]>;
  getConversationsByUser(userId: string): Promise<{ jobId: string | null; otherUserId: string; otherUserName: string; lastMessage: Message }[]>;
  getMessagesBetweenUsers(userId1: string, userId2: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessagesAsRead(userId: string, jobId: string): Promise<void>;
  
  getPortfolioImage(id: string): Promise<PortfolioImage | undefined>;
  getPortfolioImagesByProvider(providerId: string): Promise<PortfolioImage[]>;
  createPortfolioImage(image: InsertPortfolioImage): Promise<PortfolioImage>;
  deletePortfolioImage(id: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllProviders(): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, "provider"));
  }

  async getJob(id: string): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, id));
    return job || undefined;
  }

  async getAllJobs(): Promise<Job[]> {
    return await db.select().from(jobs).orderBy(desc(jobs.timestamp));
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const [job] = await db
      .insert(jobs)
      .values(insertJob)
      .returning();
    return job;
  }

  async updateJob(id: string, updates: Partial<Job>): Promise<Job | undefined> {
    const [job] = await db
      .update(jobs)
      .set(updates)
      .where(eq(jobs.id, id))
      .returning();
    return job || undefined;
  }

  async getReview(id: string): Promise<Review | undefined> {
    const [review] = await db.select().from(reviews).where(eq(reviews.id, id));
    return review || undefined;
  }

  async getReviewsByProvider(providerId: string): Promise<Review[]> {
    return await db.select().from(reviews).where(eq(reviews.providerId, providerId)).orderBy(desc(reviews.timestamp));
  }

  async getReviewByJobId(jobId: string): Promise<Review | undefined> {
    const [review] = await db.select().from(reviews).where(eq(reviews.jobId, jobId));
    return review || undefined;
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const [review] = await db
      .insert(reviews)
      .values(insertReview)
      .returning();
    return review;
  }

  async getProviderRating(providerId: string): Promise<number> {
    const result = await db
      .select({ avgRating: avg(reviews.rating) })
      .from(reviews)
      .where(eq(reviews.providerId, providerId));
    
    return result[0]?.avgRating ? Number(result[0].avgRating) : 0;
  }

  async getMessage(id: string): Promise<Message | undefined> {
    const [message] = await db.select().from(messages).where(eq(messages.id, id));
    return message || undefined;
  }

  async getMessagesByJob(jobId: string): Promise<Message[]> {
    return await db.select().from(messages).where(eq(messages.jobId, jobId)).orderBy(messages.timestamp);
  }

  async getMessagesBetweenUsers(userId1: string, userId2: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(
        and(
          or(
            and(eq(messages.senderId, userId1), eq(messages.receiverId, userId2)),
            and(eq(messages.senderId, userId2), eq(messages.receiverId, userId1))
          ),
          isNull(messages.jobId)
        )
      )
      .orderBy(messages.timestamp);
  }

  async getConversationsByUser(userId: string): Promise<{ jobId: string | null; otherUserId: string; otherUserName: string; lastMessage: Message }[]> {
    const userMessages = await db
      .select()
      .from(messages)
      .where(or(eq(messages.senderId, userId), eq(messages.receiverId, userId)))
      .orderBy(desc(messages.timestamp));

    const conversationsMap = new Map<string, { jobId: string | null; otherUserId: string; lastMessage: Message }>();

    for (const message of userMessages) {
      // For direct messages (no jobId), use a synthetic key based on the other user
      const otherUserId = message.senderId === userId ? message.receiverId : message.senderId;
      const conversationKey = message.jobId || `direct-${otherUserId}`;
      
      if (!conversationsMap.has(conversationKey)) {
        conversationsMap.set(conversationKey, {
          jobId: message.jobId,
          otherUserId,
          lastMessage: message,
        });
      }
    }

    const conversations = [];
    for (const conv of Array.from(conversationsMap.values())) {
      const otherUser = await this.getUser(conv.otherUserId);
      conversations.push({
        jobId: conv.jobId,
        otherUserId: conv.otherUserId,
        otherUserName: otherUser?.name || "Unknown",
        lastMessage: conv.lastMessage,
      });
    }

    return conversations;
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db
      .insert(messages)
      .values(insertMessage)
      .returning();
    return message;
  }

  async markMessagesAsRead(userId: string, jobId: string): Promise<void> {
    await db
      .update(messages)
      .set({ read: 1 })
      .where(and(eq(messages.jobId, jobId), eq(messages.receiverId, userId)));
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getPortfolioImage(id: string): Promise<PortfolioImage | undefined> {
    const [image] = await db.select().from(portfolioImages).where(eq(portfolioImages.id, id));
    return image || undefined;
  }

  async getPortfolioImagesByProvider(providerId: string): Promise<PortfolioImage[]> {
    return await db.select().from(portfolioImages).where(eq(portfolioImages.providerId, providerId)).orderBy(desc(portfolioImages.timestamp));
  }

  async createPortfolioImage(insertImage: InsertPortfolioImage): Promise<PortfolioImage> {
    const [image] = await db
      .insert(portfolioImages)
      .values(insertImage)
      .returning();
    return image;
  }

  async deletePortfolioImage(id: string): Promise<void> {
    await db.delete(portfolioImages).where(eq(portfolioImages.id, id));
  }
}

export const storage = new DatabaseStorage();
