import { useQuery, useMutation } from "@tanstack/react-query";
import { useState, useEffect, useRef } from "react";
import { useLocation, useRoute } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ArrowLeft, Send } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  jobId: string;
  content: string;
  timestamp: Date;
  read: number;
}

interface Conversation {
  jobId: string | null;
  otherUserId: string;
  otherUserName: string;
  lastMessage: Message;
}

export default function Messages() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/messages/:conversationId");
  const conversationId = params?.conversationId;
  const { toast } = useToast();
  const [user, setUser] = useState<any>(null);
  const [messageContent, setMessageContent] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Check if this is a direct message conversation
  const isDirectMessage = conversationId?.startsWith("direct-");
  const otherUserId = isDirectMessage ? conversationId?.replace("direct-", "") : null;

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (!storedUser) {
      setLocation("/");
      return;
    }
    setUser(JSON.parse(storedUser));
  }, [setLocation]);

  const { data: conversations = [] } = useQuery<Conversation[]>({
    queryKey: ["/api/conversations"],
    enabled: !!user,
  });

  // Fetch messages for job-based or direct message conversations
  const { data: messages = [] } = useQuery<Message[]>({
    queryKey: isDirectMessage 
      ? ["/api/direct-messages", otherUserId] 
      : ["/api/messages", conversationId],
    enabled: !!conversationId && !!user,
    refetchInterval: 3000,
  });

  // Find the selected conversation or create synthetic one for new direct messages
  const selectedConversation = conversations.find((c) => {
    if (isDirectMessage) {
      return c.jobId === null && c.otherUserId === otherUserId;
    }
    return c.jobId === conversationId;
  }) || (isDirectMessage && otherUserId ? {
    jobId: null,
    otherUserId: otherUserId,
    otherUserName: "Provider",
    lastMessage: {} as Message
  } : null);

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      if (!selectedConversation) return;
      return await apiRequest("POST", "/api/messages", {
        receiverId: selectedConversation.otherUserId,
        jobId: isDirectMessage ? null : conversationId,
        content,
      });
    },
    onSuccess: () => {
      setMessageContent("");
      if (isDirectMessage) {
        queryClient.invalidateQueries({ queryKey: ["/api/direct-messages", otherUserId] });
      } else {
        queryClient.invalidateQueries({ queryKey: ["/api/messages", conversationId] });
      }
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageContent.trim()) return;
    sendMessageMutation.mutate(messageContent);
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-500 to-blue-600 p-4">
      <div className="max-w-6xl mx-auto pt-4 pb-24">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {conversationId && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setLocation("/messages")}
                  data-testid="button-back-to-conversations"
                >
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              )}
              <span>Messages</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4">
              <div className={`${conversationId ? "hidden md:block" : "col-span-3 md:col-span-1"}`}>
                <h3 className="text-sm font-semibold mb-3">Conversations</h3>
                {conversations.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8" data-testid="text-no-conversations">
                    No conversations yet
                  </p>
                ) : (
                  <div className="space-y-2">
                    {conversations.map((conv) => {
                      const convId = conv.jobId || `direct-${conv.otherUserId}`;
                      return (
                        <div
                          key={convId}
                          onClick={() => setLocation(`/messages/${convId}`)}
                          className={`p-3 rounded-md cursor-pointer hover-elevate ${
                            conversationId === convId ? "bg-muted" : ""
                          }`}
                          data-testid={`conversation-${convId}`}
                        >
                        <p className="font-semibold text-sm">{conv.otherUserName}</p>
                        <p className="text-xs text-muted-foreground truncate">
                          {conv.lastMessage.content}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {format(new Date(conv.lastMessage.timestamp), "MMM d, h:mm a")}
                        </p>
                      </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className={`${!conversationId ? "hidden md:block" : "col-span-3 md:col-span-2"}`}>
                {!conversationId ? (
                  <div className="flex items-center justify-center h-64 text-muted-foreground">
                    Select a conversation to start messaging
                  </div>
                ) : (
                  <div className="flex flex-col h-[500px]">
                    <div className="mb-3 pb-3 border-b">
                      <p className="font-semibold">{selectedConversation?.otherUserName}</p>
                    </div>

                    <ScrollArea className="flex-1 pr-4">
                      <div className="space-y-3">
                        {messages.map((message) => {
                          const isSender = message.senderId === user.id;
                          return (
                            <div
                              key={message.id}
                              className={`flex ${isSender ? "justify-end" : "justify-start"}`}
                              data-testid={`message-${message.id}`}
                            >
                              <div
                                className={`max-w-xs px-4 py-2 rounded-lg ${
                                  isSender
                                    ? "bg-primary text-primary-foreground"
                                    : "bg-muted"
                                }`}
                              >
                                <p className="text-sm">{message.content}</p>
                                <p className="text-xs opacity-70 mt-1">
                                  {format(new Date(message.timestamp), "h:mm a")}
                                </p>
                              </div>
                            </div>
                          );
                        })}
                        <div ref={messagesEndRef} />
                      </div>
                    </ScrollArea>

                    <form onSubmit={handleSendMessage} className="flex gap-2 mt-3">
                      <Input
                        placeholder="Type a message..."
                        value={messageContent}
                        onChange={(e) => setMessageContent(e.target.value)}
                        data-testid="input-message"
                      />
                      <Button
                        type="submit"
                        size="icon"
                        disabled={sendMessageMutation.isPending || !messageContent.trim()}
                        data-testid="button-send-message"
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    </form>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
