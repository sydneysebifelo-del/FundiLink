import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertJobSchema, insertReviewSchema, insertMessageSchema, insertPortfolioImageSchema } from "@shared/schema";
import { ObjectStorageService, ObjectNotFoundError } from "./objectStorage";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/signup", async (req, res) => {
    try {
      console.log("Signup attempt - received data:", { ...req.body, password: '***' });
      
      const validatedData = insertUserSchema.parse(req.body);
      console.log("Validation passed");
      
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }
      console.log("No existing user found");

      // Normalize profile picture URL if it's a Google Cloud Storage URL
      if (validatedData.profilePicture && validatedData.profilePicture.startsWith('https://storage.googleapis.com/')) {
        const objectStorageService = new ObjectStorageService();
        validatedData.profilePicture = objectStorageService.normalizeObjectEntityPath(validatedData.profilePicture);
        console.log("Normalized profile picture URL to:", validatedData.profilePicture);
      }

      console.log("About to create user with data:", { ...validatedData, password: '***' });
      const user = await storage.createUser(validatedData);
      console.log("User created successfully:", user.id);
      
      const { password, ...userWithoutPassword } = user;
      
      res.json({ user: userWithoutPassword });
    } catch (error: any) {
      console.error("=== SIGNUP ERROR ===");
      console.error("Error message:", error.message);
      console.error("Error name:", error.name);
      console.error("Error code:", error.code);
      console.error("Full error:", error);
      console.error("Error stack:", error.stack);
      console.error("===================");
      
      res.status(400).json({ 
        message: error.message || "Invalid data",
        details: error.code ? `Error code: ${error.code}` : undefined
      });
    }
  });

  app.post("/api/login", async (req, res) => {
    try {
      const { email, password, role } = req.body;

      if (!email || !password || !role) {
        return res.status(400).json({ message: "Email, password, and role are required" });
      }

      const user = await storage.getUserByEmail(email);
      if (!user || user.password !== password || user.role !== role) {
        return res.status(401).json({ message: "Invalid credentials or role mismatch" });
      }

      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Login failed" });
    }
  });

  app.get("/api/jobs", async (req, res) => {
    try {
      const jobs = await storage.getAllJobs();
      res.json(jobs);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });

  app.get("/api/providers", async (req, res) => {
    try {
      const providers = await storage.getAllProviders();
      
      // Get ratings for each provider
      const providersWithRatings = await Promise.all(
        providers.map(async ({ password, ...provider }) => {
          const rating = await storage.getProviderRating(provider.id);
          return {
            ...provider,
            averageRating: rating,
          };
        })
      );
      
      res.json(providersWithRatings);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch providers" });
    }
  });

  app.post("/api/jobs", async (req, res) => {
    try {
      const userStr = req.headers["x-user"];
      if (!userStr || typeof userStr !== "string") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = JSON.parse(userStr);
      
      const jobData = {
        service: req.body.service,
        description: req.body.description,
        location: req.body.location,
        status: "Pending",
        postedBy: user.name,
        postedById: user.id,
        acceptedBy: null,
        acceptedById: null,
      };

      const validatedData = insertJobSchema.parse(jobData);
      const job = await storage.createJob(validatedData);
      
      res.json(job);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to create job" });
    }
  });

  app.post("/api/jobs/:id/accept", async (req, res) => {
    try {
      const userStr = req.headers["x-user"];
      if (!userStr || typeof userStr !== "string") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = JSON.parse(userStr);
      const jobId = req.params.id;

      const job = await storage.getJob(jobId);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }

      if (job.status.startsWith("Accepted")) {
        return res.status(400).json({ message: "Job already accepted" });
      }

      const updatedJob = await storage.updateJob(jobId, {
        status: `Accepted by ${user.name}`,
        acceptedBy: user.name,
        acceptedById: user.id,
      });

      res.json(updatedJob);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to accept job" });
    }
  });

  app.get("/api/providers/:id/reviews", async (req, res) => {
    try {
      const providerId = req.params.id;
      const reviewsData = await storage.getReviewsByProvider(providerId);
      const rating = await storage.getProviderRating(providerId);
      
      res.json({ reviews: reviewsData, averageRating: rating });
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.get("/api/providers/:id", async (req, res) => {
    try {
      const providerId = req.params.id;
      const provider = await storage.getUser(providerId);
      
      if (!provider || provider.role !== "provider") {
        return res.status(404).json({ message: "Provider not found" });
      }

      const { password, ...providerWithoutPassword } = provider;
      const rating = await storage.getProviderRating(providerId);
      
      res.json({ ...providerWithoutPassword, averageRating: rating });
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch provider" });
    }
  });

  app.post("/api/reviews", async (req, res) => {
    try {
      const userStr = req.headers["x-user"];
      if (!userStr || typeof userStr !== "string") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = JSON.parse(userStr);
      
      if (user.role !== "client") {
        return res.status(403).json({ message: "Only clients can submit reviews" });
      }

      const existingReview = await storage.getReviewByJobId(req.body.jobId);
      if (existingReview) {
        return res.status(400).json({ message: "Review already submitted for this job" });
      }

      const reviewData = {
        providerId: req.body.providerId,
        clientId: user.id,
        jobId: req.body.jobId,
        rating: req.body.rating,
        comment: req.body.comment,
      };

      const validatedData = insertReviewSchema.parse(reviewData);
      const review = await storage.createReview(validatedData);
      
      res.json(review);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to create review" });
    }
  });

  app.get("/api/conversations", async (req, res) => {
    try {
      const userStr = req.headers["x-user"];
      if (!userStr || typeof userStr !== "string") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = JSON.parse(userStr);
      const conversations = await storage.getConversationsByUser(user.id);
      
      res.json(conversations);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });

  app.get("/api/messages/:jobId", async (req, res) => {
    try {
      const userStr = req.headers["x-user"];
      if (!userStr || typeof userStr !== "string") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = JSON.parse(userStr);
      const jobId = req.params.jobId;
      const messagesData = await storage.getMessagesByJob(jobId);
      
      await storage.markMessagesAsRead(user.id, jobId);
      
      res.json(messagesData);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.get("/api/direct-messages/:userId", async (req, res) => {
    try {
      const userStr = req.headers["x-user"];
      if (!userStr || typeof userStr !== "string") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = JSON.parse(userStr);
      const otherUserId = req.params.userId;
      const messagesData = await storage.getMessagesBetweenUsers(user.id, otherUserId);
      
      res.json(messagesData);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post("/api/messages", async (req, res) => {
    try {
      const userStr = req.headers["x-user"];
      if (!userStr || typeof userStr !== "string") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = JSON.parse(userStr);
      
      const messageData = {
        senderId: user.id,
        receiverId: req.body.receiverId,
        jobId: req.body.jobId,
        content: req.body.content,
      };

      const validatedData = insertMessageSchema.parse(messageData);
      const message = await storage.createMessage(validatedData);
      
      res.json(message);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to send message" });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const userStr = req.headers["x-user"];
      if (!userStr || typeof userStr !== "string") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = JSON.parse(userStr);
      const userId = req.params.id;

      if (user.id !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const updates = {
        profilePicture: req.body.profilePicture,
        phone: req.body.phone,
        bio: req.body.bio,
        skill: req.body.skill,
      };

      const updatedUser = await storage.updateUser(userId, updates);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to update user" });
    }
  });

  app.get("/api/providers/:id/portfolio", async (req, res) => {
    try {
      const providerId = req.params.id;
      const images = await storage.getPortfolioImagesByProvider(providerId);
      
      res.json(images);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch portfolio" });
    }
  });

  app.post("/api/providers/:id/portfolio", async (req, res) => {
    try {
      const userStr = req.headers["x-user"];
      if (!userStr || typeof userStr !== "string") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = JSON.parse(userStr);
      const providerId = req.params.id;

      if (user.id !== providerId || user.role !== "provider") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const imageData = {
        providerId,
        imageUrl: req.body.imageUrl,
        caption: req.body.caption,
      };

      const validatedData = insertPortfolioImageSchema.parse(imageData);
      const image = await storage.createPortfolioImage(validatedData);
      
      res.json(image);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to add portfolio image" });
    }
  });

  app.delete("/api/portfolio/:id", async (req, res) => {
    try {
      const userStr = req.headers["x-user"];
      if (!userStr || typeof userStr !== "string") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const imageId = req.params.id;
      const image = await storage.getPortfolioImage(imageId);
      
      if (!image) {
        return res.status(404).json({ message: "Image not found" });
      }

      const user = JSON.parse(userStr);
      if (user.id !== image.providerId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      await storage.deletePortfolioImage(imageId);
      
      res.json({ message: "Image deleted" });
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to delete image" });
    }
  });

  // Object storage endpoints
  app.post("/api/objects/upload", async (req, res) => {
    try {
      // Allow unauthenticated uploads for signup
      // User header is optional for this endpoint
      const objectStorageService = new ObjectStorageService();
      const uploadURL = await objectStorageService.getObjectEntityUploadURL();
      res.json({ uploadURL });
    } catch (error: any) {
      console.error("Error getting upload URL:", error);
      res.status(500).json({ message: "Failed to get upload URL" });
    }
  });

  app.put("/api/profile-picture", async (req, res) => {
    try {
      const userStr = req.headers["x-user"];
      if (!userStr || typeof userStr !== "string") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = JSON.parse(userStr);
      const { profilePictureURL } = req.body;

      if (!profilePictureURL) {
        return res.status(400).json({ message: "profilePictureURL is required" });
      }

      const objectStorageService = new ObjectStorageService();
      const objectPath = await objectStorageService.trySetObjectEntityAclPolicy(
        profilePictureURL,
        {
          owner: user.id,
          visibility: "public",
        }
      );

      await storage.updateUser(user.id, { profilePicture: objectPath });

      res.status(200).json({ objectPath });
    } catch (error: any) {
      console.error("Error setting profile picture:", error);
      res.status(500).json({ message: "Failed to set profile picture" });
    }
  });

  app.get("/objects/:objectPath(*)", async (req, res) => {
    const objectStorageService = new ObjectStorageService();
    try {
      const objectFile = await objectStorageService.getObjectEntityFile(
        req.path
      );
      objectStorageService.downloadObject(objectFile, res);
    } catch (error) {
      console.error("Error accessing object:", error);
      if (error instanceof ObjectNotFoundError) {
        return res.sendStatus(404);
      }
      return res.sendStatus(500);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
