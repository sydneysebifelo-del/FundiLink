import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { User, Upload } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { ObjectUploader } from "@/components/ObjectUploader";
import type { UploadResult } from "@uppy/core";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const editProfileSchema = z.object({
  phone: z.string().optional(),
  bio: z.string().optional(),
  profilePicture: z.string().optional(),
  skill: z.string().optional(),
});

type EditProfileForm = z.infer<typeof editProfileSchema>;

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  skill?: string;
  phone?: string;
  bio?: string;
  profilePicture?: string;
}

export default function EditProfile() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [uploadedImageUrl, setUploadedImageUrl] = useState<string>("");
  const [isUploading, setIsUploading] = useState(false);

  const userStr = localStorage.getItem("user");
  const currentUser: User = userStr ? JSON.parse(userStr) : null;

  const { data: user } = useQuery<User>({
    queryKey: ["/api/users", currentUser?.id],
    enabled: !!currentUser?.id,
  });

  const form = useForm<EditProfileForm>({
    resolver: zodResolver(editProfileSchema),
    defaultValues: {
      phone: currentUser?.phone || "",
      bio: currentUser?.bio || "",
      skill: currentUser?.skill || "",
      profilePicture: currentUser?.profilePicture || "",
    },
  });

  // Update form when user data loads from server
  useEffect(() => {
    if (user && !form.formState.isDirty) {
      form.reset({
        phone: user.phone || "",
        bio: user.bio || "",
        skill: user.skill || "",
        profilePicture: user.profilePicture || "",
      });
    }
  }, [user, form]);

  const updateMutation = useMutation({
    mutationFn: async (data: EditProfileForm) => {
      const response = await apiRequest("PATCH", `/api/users/${currentUser.id}`, data);
      return response;
    },
    onSuccess: (updatedUser) => {
      // Update localStorage
      localStorage.setItem("user", JSON.stringify({ ...currentUser, ...updatedUser }));
      
      toast({
        title: "Profile updated!",
        description: "Your profile has been updated successfully",
      });
      
      queryClient.invalidateQueries({ queryKey: ["/api/users", currentUser.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/providers", currentUser.id] });
      
      // Redirect to profile
      if (currentUser.role === "provider") {
        setLocation(`/provider/${currentUser.id}`);
      } else {
        setLocation("/dashboard/client");
      }
    },
    onError: (error: any) => {
      toast({
        title: "Update failed",
        description: error.message || "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  const handleGetUploadParameters = async () => {
    const response = await fetch("/api/objects/upload", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-user": JSON.stringify(currentUser),
      },
    });
    const data = await response.json();
    return {
      method: "PUT" as const,
      url: data.uploadURL,
    };
  };

  const handleUploadComplete = async (result: UploadResult<Record<string, unknown>, Record<string, unknown>>) => {
    if (result.successful && result.successful.length > 0) {
      const uploadURL = result.successful[0].uploadURL;
      if (uploadURL) {
        // Strip query parameters from the upload URL
        const cleanURL = uploadURL.split('?')[0];
        setUploadedImageUrl(cleanURL);
        form.setValue("profilePicture", cleanURL);
        
        toast({
          title: "Image uploaded!",
          description: "Your profile picture has been uploaded successfully",
        });
      }
    }
    setIsUploading(false);
  };

  const onSubmit = (data: EditProfileForm) => {
    updateMutation.mutate(data);
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-500 to-blue-600 p-4">
        <div className="max-w-md mx-auto mt-10">
          <Card>
            <CardContent className="p-8">
              <p className="text-center">Please log in to edit your profile</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const displayProfilePicture = uploadedImageUrl || form.watch("profilePicture") || user?.profilePicture;
  const displayProfilePictureSrc = displayProfilePicture ? `/api/images/${displayProfilePicture}` : undefined;

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-500 to-blue-600 p-4 pb-24">
      <div className="max-w-md mx-auto mt-10">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-2xl">
              <User size={24} />
              Edit Profile
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-6 flex flex-col items-center gap-4">
              <Avatar className="h-32 w-32">
                <AvatarImage src={displayProfilePictureSrc} alt={currentUser.name} />
                <AvatarFallback className="text-4xl bg-primary text-white">
                  {currentUser.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              
              <ObjectUploader
                maxNumberOfFiles={1}
                maxFileSize={5242880}
                onGetUploadParameters={handleGetUploadParameters}
                onComplete={handleUploadComplete}
                buttonVariant="outline"
              >
                <Upload className="mr-2 h-4 w-4" />
                {displayProfilePicture ? "Change Picture" : "Upload Picture"}
              </ObjectUploader>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                {currentUser.role === "provider" && (
                  <FormField
                    control={form.control}
                    name="skill"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Skill/Profession</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="e.g., Plumber, Electrician" 
                            {...field}
                            data-testid="input-skill"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter your phone number" 
                          {...field}
                          data-testid="input-phone"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="bio"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bio</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Tell us about yourself" 
                          {...field}
                          data-testid="input-bio"
                          rows={4}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex gap-2 pt-4">
                  <Button
                    type="submit"
                    className="flex-1"
                    disabled={updateMutation.isPending}
                    data-testid="button-save-profile"
                  >
                    {updateMutation.isPending ? "Saving..." : "Save Changes"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      if (currentUser.role === "provider") {
                        setLocation(`/provider/${currentUser.id}`);
                      } else {
                        setLocation("/dashboard/client");
                      }
                    }}
                    data-testid="button-cancel"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
