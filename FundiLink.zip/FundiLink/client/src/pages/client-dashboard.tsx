import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { LogOut, Plus, Users } from "lucide-react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ProviderCard } from "@/components/provider-card";
import { BottomNav } from "@/components/bottom-nav";
import { useEffect, useState } from "react";

const jobSchema = z.object({
  service: z.string().min(1, "Service type is required"),
  description: z.string().min(1, "Description is required"),
  location: z.string().min(1, "Location is required"),
});

type JobForm = z.infer<typeof jobSchema>;

export default function ClientDashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (!storedUser) {
      setLocation("/");
      return;
    }
    setUser(JSON.parse(storedUser));
  }, [setLocation]);

  const form = useForm<JobForm>({
    resolver: zodResolver(jobSchema),
    defaultValues: {
      service: "",
      description: "",
      location: "",
    },
  });

  const { data: providers = [], isLoading } = useQuery<any[]>({
    queryKey: ["/api/providers"],
  });

  const postJobMutation = useMutation({
    mutationFn: async (data: JobForm) => {
      const response = await apiRequest("POST", "/api/jobs", data);
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Job posted!",
        description: "Your job has been posted successfully",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to post job",
        variant: "destructive",
      });
    },
  });

  const handleLogout = () => {
    localStorage.removeItem("user");
    toast({
      title: "Logged out",
      description: "You have been logged out successfully",
    });
    setLocation("/");
  };

  const onSubmit = (data: JobForm) => {
    postJobMutation.mutate(data);
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-500 to-blue-600 flex flex-col items-center text-white p-4 pb-24">
      <div className="w-full max-w-sm mt-6">
        <Card className="bg-white text-foreground shadow-xl">
          <CardContent className="flex flex-col gap-4 p-6 max-h-[80vh] overflow-y-auto">
            <h2 className="text-xl font-semibold text-center text-primary" data-testid="text-welcome">
              Welcome, {user.name}!
            </h2>

            <div className="flex flex-col gap-3 border-b pb-4">
              <h3 className="text-base font-semibold text-foreground flex items-center gap-2">
                <Plus size={18} />
                Post a Job
              </h3>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
                  <FormField
                    control={form.control}
                    name="service"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm">Service Type</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="e.g. Plumber, Electrician" 
                            {...field}
                            data-testid="input-service"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm">Job Description</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Describe what you need" 
                            {...field}
                            data-testid="input-description"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm">Location</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Enter location" 
                            {...field}
                            data-testid="input-location"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={postJobMutation.isPending}
                    data-testid="button-post-job"
                  >
                    {postJobMutation.isPending ? "Posting..." : "Post Job"}
                  </Button>
                </form>
              </Form>
            </div>

            <div className="flex flex-col gap-3">
              <h3 className="text-base font-semibold text-foreground flex items-center gap-2">
                <Users size={18} />
                Service Providers Near You
              </h3>
              {isLoading && (
                <p className="text-muted-foreground text-sm text-center py-4">Loading providers...</p>
              )}
              {!isLoading && providers.length === 0 && (
                <p className="text-muted-foreground text-sm text-center py-4" data-testid="text-no-providers">
                  No service providers available yet.
                </p>
              )}
              <div className="space-y-3">
                {providers.map((provider) => (
                  <ProviderCard key={provider.id} provider={provider} />
                ))}
              </div>
            </div>

            <Button 
              onClick={handleLogout} 
              variant="secondary"
              className="mt-4 flex items-center justify-center gap-2"
              data-testid="button-logout"
            >
              <LogOut size={16} />
              Logout
            </Button>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </div>
  );
}
